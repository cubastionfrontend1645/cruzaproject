import { LightningElement } from 'lwc';

export default class Cr_footer extends LightningElement {}