import { LightningElement, track, wire, api } from "lwc";
// import getImagesAsBase64 from "@salesforce/apex/DemoClass.getImagesAsBase64"; //TermConditionId : a1seX000000Eu5ZQAS
// import getDataFromDLO from "@salesforce/apex/DataCloudDataService.getParsedDataFromDLO";

// import {
//   subscribe,
//   unsubscribe,
//   onError,
//   setDebugFlag,
//   isEmpEnabled
// } from "lightning/empApi";
// import { loadScript } from "lightning/platformResourceLoader";
// import cometdlwc from "@salesforce/resourceUrl/cometd";
// import getSessionId from "@salesforce/apex/CCP2_Notification_Controller.getSessionId";

export default class VehicleServiceTimeline extends LightningElement {
  // channelName = "/event/CCP_Notification__e";
  // sessionId;
  // subscription = {};
  // connectedCallback() {
  //   let dates = [
  //     {
  //       date: "2025-01-31",
  //       maintenance: [
  //         {
  //           Id: "a1deX000000CIUDQA4",
  //           CCP2_Branch__c: "a1VIo0000000QQ2MAM",
  //           Maintenance_Type__c: "Scheduled",
  //           Recieving_Destination__c: "本社",
  //           Schedule_Date__c: "2025-01-31",
  //           Schedule_EndDate__c: "2025-02-13",
  //           Service_Factory__c: "自社",
  //           Service_Type__c: "車検整備",
  //           Status__c: "In Progress",
  //           Vehicle__c: "a1aIo000000HDryIAG"
  //         }
  //       ],
  //       isExpirationDate: false,
  //       countOfMaintenance: 1,
  //       isContinue: false,
  //       isMultiple: false,
  //       width:
  //         "width: calc(100% + 4px - 6px); border-top-right-radius: 0px; border-bottom-right-radius: 0px; z-index:2;",
  //       cssClass: "green-box",
  //       isStart: true,
  //       isEnd: false,
  //       serviceType: "車検整備",
  //       classForBoxes: "Calender-tile-white",
  //       isMaintenanceAvailable: "true"
  //     },
  //     {
  //       date: "2025-02-01",
  //       maintenance: [
  //         {
  //           Id: "a1deX000000CIUDQA4",
  //           CCP2_Branch__c: "a1VIo0000000QQ2MAM",
  //           Maintenance_Type__c: "Scheduled",
  //           Recieving_Destination__c: "本社",
  //           Schedule_Date__c: "2025-01-31",
  //           Schedule_EndDate__c: "2025-02-13",
  //           Service_Factory__c: "自社",
  //           Service_Type__c: "車検整備",
  //           Status__c: "In Progress",
  //           Vehicle__c: "a1aIo000000HDryIAG"
  //         },
  //         {
  //           Id: "a1deX000000CbAHQA0",
  //           CCP2_Branch__c: "a1VIo0000000QQ2MAM",
  //           Maintenance_Type__c: "Scheduled",
  //           Recieving_Destination__c: "本社",
  //           Schedule_Date__c: "2025-02-01",
  //           Schedule_EndDate__c: "2025-02-03",
  //           Service_Factory__c: "自社",
  //           Service_Type__c: "車検整備",
  //           Status__c: "In Progress",
  //           Vehicle__c: "a1aIo000000HDryIAG"
  //         }
  //       ],
  //       isExpirationDate: false,
  //       countOfMaintenance: 1,
  //       isContinue: false,
  //       isMultiple: true,
  //       width:
  //         "width: calc(100% + 4px); left: 0px; border-top-right-radius: 0px; border-bottom-right-radius: 0px;height: calc(50% - 2px); font-size:11px;",
  //       cssClass: "green-box",
  //       isStart: false,
  //       isEnd: false,
  //       serviceType: "",
  //       classForBoxes: "Calender-tile-grey",
  //       isMaintenanceAvailable: "true"
  //     },
  //     {
  //       date: "2025-02-02",
  //       maintenance: [
  //         {
  //           Id: "a1deX000000CIUDQA4",
  //           CCP2_Branch__c: "a1VIo0000000QQ2MAM",
  //           Maintenance_Type__c: "Scheduled",
  //           Recieving_Destination__c: "本社",
  //           Schedule_Date__c: "2025-01-31",
  //           Schedule_EndDate__c: "2025-02-13",
  //           Service_Factory__c: "自社",
  //           Service_Type__c: "車検整備",
  //           Status__c: "In Progress",
  //           Vehicle__c: "a1aIo000000HDryIAG"
  //         },
  //         {
  //           Id: "a1deX000000CbAHQA0",
  //           CCP2_Branch__c: "a1VIo0000000QQ2MAM",
  //           Maintenance_Type__c: "Scheduled",
  //           Recieving_Destination__c: "本社",
  //           Schedule_Date__c: "2025-02-01",
  //           Schedule_EndDate__c: "2025-02-03",
  //           Service_Factory__c: "自社",
  //           Service_Type__c: "車検整備",
  //           Status__c: "In Progress",
  //           Vehicle__c: "a1aIo000000HDryIAG"
  //         }
  //       ],
  //       isExpirationDate: false,
  //       countOfMaintenance: 1,
  //       isContinue: false,
  //       isMultiple: true,
  //       width:
  //         "width: calc(100% + 4px); left: 0px; border-top-right-radius: 0px; border-bottom-right-radius: 0px;height: calc(50% - 2px); font-size:11px;",
  //       cssClass: "green-box",
  //       isStart: false,
  //       isEnd: false,
  //       serviceType: "",
  //       classForBoxes: "Calender-tile-grey",
  //       isMaintenanceAvailable: "true"
  //     },
  //     {
  //       date: "2025-02-03",
  //       maintenance: [
  //         {
  //           Id: "a1deX000000CIUDQA4",
  //           CCP2_Branch__c: "a1VIo0000000QQ2MAM",
  //           Maintenance_Type__c: "Scheduled",
  //           Recieving_Destination__c: "本社",
  //           Schedule_Date__c: "2025-01-31",
  //           Schedule_EndDate__c: "2025-02-13",
  //           Service_Factory__c: "自社",
  //           Service_Type__c: "車検整備",
  //           Status__c: "In Progress",
  //           Vehicle__c: "a1aIo000000HDryIAG"
  //         },
  //         {
  //           Id: "a1deX000000CbAHQA0",
  //           CCP2_Branch__c: "a1VIo0000000QQ2MAM",
  //           Maintenance_Type__c: "Scheduled",
  //           Recieving_Destination__c: "本社",
  //           Schedule_Date__c: "2025-02-01",
  //           Schedule_EndDate__c: "2025-02-03",
  //           Service_Factory__c: "自社",
  //           Service_Type__c: "車検整備",
  //           Status__c: "In Progress",
  //           Vehicle__c: "a1aIo000000HDryIAG"
  //         }
  //       ],
  //       isExpirationDate: false,
  //       countOfMaintenance: 1,
  //       isContinue: false,
  //       isMultiple: true,
  //       width:
  //         "width: calc(100% + 4px); left: 0px; border-top-right-radius: 0px; border-bottom-right-radius: 0px;height: calc(50% - 2px); font-size:11px;",
  //       cssClass: "green-box",
  //       isStart: false,
  //       isEnd: false,
  //       serviceType: "",
  //       classForBoxes: "Calender-tile-white",
  //       isMaintenanceAvailable: "true"
  //     },
  //     {
  //       date: "2025-02-04",
  //       maintenance: [
  //         {
  //           Id: "a1deX000000CIUDQA4",
  //           CCP2_Branch__c: "a1VIo0000000QQ2MAM",
  //           Maintenance_Type__c: "Scheduled",
  //           Recieving_Destination__c: "本社",
  //           Schedule_Date__c: "2025-01-31",
  //           Schedule_EndDate__c: "2025-02-13",
  //           Service_Factory__c: "自社",
  //           Service_Type__c: "車検整備",
  //           Status__c: "In Progress",
  //           Vehicle__c: "a1aIo000000HDryIAG"
  //         },
  //         {
  //           Id: "a1deX000000CIafQAG",
  //           CCP2_Branch__c: "a1VIo0000000QQ2MAM",
  //           Maintenance_Type__c: "Scheduled",
  //           Recieving_Destination__c: "本社",
  //           Schedule_Date__c: "2025-02-04",
  //           Schedule_EndDate__c: "2025-02-06",
  //           Service_Factory__c: "自社",
  //           Service_Type__c: "3か月点検",
  //           Status__c: "In Progress",
  //           Vehicle__c: "a1aIo000000HDryIAG"
  //         }
  //       ],
  //       isExpirationDate: false,
  //       countOfMaintenance: 1,
  //       isContinue: false,
  //       isMultiple: true,
  //       width:
  //         "width: calc(100% + 4px); left: 0px; border-top-right-radius: 0px; border-bottom-right-radius: 0px;height: calc(50% - 2px); font-size:11px;",
  //       cssClass: "green-box",
  //       isStart: false,
  //       isEnd: false,
  //       serviceType: "",
  //       classForBoxes: "Calender-tile-white",
  //       isMaintenanceAvailable: "true"
  //     },
  //     {
  //       date: "2025-02-05",
  //       maintenance: [
  //         {
  //           Id: "a1deX000000CIUDQA4",
  //           CCP2_Branch__c: "a1VIo0000000QQ2MAM",
  //           Maintenance_Type__c: "Scheduled",
  //           Recieving_Destination__c: "本社",
  //           Schedule_Date__c: "2025-01-31",
  //           Schedule_EndDate__c: "2025-02-13",
  //           Service_Factory__c: "自社",
  //           Service_Type__c: "車検整備",
  //           Status__c: "In Progress",
  //           Vehicle__c: "a1aIo000000HDryIAG"
  //         },
  //         {
  //           Id: "a1deX000000CIafQAG",
  //           CCP2_Branch__c: "a1VIo0000000QQ2MAM",
  //           Maintenance_Type__c: "Scheduled",
  //           Recieving_Destination__c: "本社",
  //           Schedule_Date__c: "2025-02-04",
  //           Schedule_EndDate__c: "2025-02-06",
  //           Service_Factory__c: "自社",
  //           Service_Type__c: "3か月点検",
  //           Status__c: "In Progress",
  //           Vehicle__c: "a1aIo000000HDryIAG"
  //         }
  //       ],
  //       isExpirationDate: false,
  //       countOfMaintenance: 1,
  //       isContinue: false,
  //       isMultiple: true,
  //       width:
  //         "width: calc(100% + 4px); left: 0px; border-top-right-radius: 0px; border-bottom-right-radius: 0px;height: calc(50% - 2px); font-size:11px;",
  //       cssClass: "green-box",
  //       isStart: false,
  //       isEnd: false,
  //       serviceType: "",
  //       classForBoxes: "Calender-tile-white",
  //       isMaintenanceAvailable: "true"
  //     },
  //     {
  //       date: "2025-02-06",
  //       maintenance: [
  //         {
  //           Id: "a1deX000000CIUDQA4",
  //           CCP2_Branch__c: "a1VIo0000000QQ2MAM",
  //           Maintenance_Type__c: "Scheduled",
  //           Recieving_Destination__c: "本社",
  //           Schedule_Date__c: "2025-01-31",
  //           Schedule_EndDate__c: "2025-02-13",
  //           Service_Factory__c: "自社",
  //           Service_Type__c: "車検整備",
  //           Status__c: "In Progress",
  //           Vehicle__c: "a1aIo000000HDryIAG"
  //         },
  //         {
  //           Id: "a1deX000000CIafQAG",
  //           CCP2_Branch__c: "a1VIo0000000QQ2MAM",
  //           Maintenance_Type__c: "Scheduled",
  //           Recieving_Destination__c: "本社",
  //           Schedule_Date__c: "2025-02-04",
  //           Schedule_EndDate__c: "2025-02-06",
  //           Service_Factory__c: "自社",
  //           Service_Type__c: "3か月点検",
  //           Status__c: "In Progress",
  //           Vehicle__c: "a1aIo000000HDryIAG"
  //         }
  //       ],
  //       isExpirationDate: false,
  //       countOfMaintenance: 1,
  //       isContinue: false,
  //       isMultiple: true,
  //       width:
  //         "width: calc(100% + 4px); left: 0px; border-top-right-radius: 0px; border-bottom-right-radius: 0px;height: calc(50% - 2px); font-size:11px;",
  //       cssClass: "green-box",
  //       isStart: false,
  //       isEnd: false,
  //       serviceType: "",
  //       classForBoxes: "Calender-tile-white",
  //       isMaintenanceAvailable: "true"
  //     },
  //     {
  //       date: "2025-02-07",
  //       maintenance: [
  //         {
  //           Id: "a1deX000000CIUDQA4",
  //           CCP2_Branch__c: "a1VIo0000000QQ2MAM",
  //           Maintenance_Type__c: "Scheduled",
  //           Recieving_Destination__c: "本社",
  //           Schedule_Date__c: "2025-01-31",
  //           Schedule_EndDate__c: "2025-02-13",
  //           Service_Factory__c: "自社",
  //           Service_Type__c: "車検整備",
  //           Status__c: "In Progress",
  //           Vehicle__c: "a1aIo000000HDryIAG"
  //         }
  //       ],
  //       isExpirationDate: false,
  //       countOfMaintenance: 1,
  //       isContinue: false,
  //       isMultiple: false,
  //       width:
  //         "width: calc(100% + 4px); left: 0px; border-top-right-radius: 0px; border-bottom-right-radius: 0px;",
  //       cssClass: "green-box",
  //       isStart: false,
  //       isEnd: false,
  //       serviceType: "",
  //       classForBoxes: "Calender-tile-white",
  //       isMaintenanceAvailable: "true"
  //     },
  //     {
  //       date: "2025-02-08",
  //       maintenance: [
  //         {
  //           Id: "a1deX000000CIUDQA4",
  //           CCP2_Branch__c: "a1VIo0000000QQ2MAM",
  //           Maintenance_Type__c: "Scheduled",
  //           Recieving_Destination__c: "本社",
  //           Schedule_Date__c: "2025-01-31",
  //           Schedule_EndDate__c: "2025-02-13",
  //           Service_Factory__c: "自社",
  //           Service_Type__c: "車検整備",
  //           Status__c: "In Progress",
  //           Vehicle__c: "a1aIo000000HDryIAG"
  //         }
  //       ],
  //       isExpirationDate: false,
  //       countOfMaintenance: 1,
  //       isContinue: false,
  //       isMultiple: false,
  //       width:
  //         "width: calc(100% + 4px); left: 0px; border-top-right-radius: 0px; border-bottom-right-radius: 0px;",
  //       cssClass: "green-box",
  //       isStart: false,
  //       isEnd: false,
  //       serviceType: "",
  //       classForBoxes: "Calender-tile-grey",
  //       isMaintenanceAvailable: "true"
  //     },
  //     {
  //       date: "2025-02-09",
  //       maintenance: [
  //         {
  //           Id: "a1deX000000CIUDQA4",
  //           CCP2_Branch__c: "a1VIo0000000QQ2MAM",
  //           Maintenance_Type__c: "Scheduled",
  //           Recieving_Destination__c: "本社",
  //           Schedule_Date__c: "2025-01-31",
  //           Schedule_EndDate__c: "2025-02-13",
  //           Service_Factory__c: "自社",
  //           Service_Type__c: "車検整備",
  //           Status__c: "In Progress",
  //           Vehicle__c: "a1aIo000000HDryIAG"
  //         }
  //       ],
  //       isExpirationDate: false,
  //       countOfMaintenance: 1,
  //       isContinue: false,
  //       isMultiple: false,
  //       width:
  //         "width: calc(100% + 4px); left: 0px; border-top-right-radius: 0px; border-bottom-right-radius: 0px;",
  //       cssClass: "green-box",
  //       isStart: false,
  //       isEnd: false,
  //       serviceType: "",
  //       classForBoxes: "Calender-tile-grey",
  //       isMaintenanceAvailable: "true"
  //     },
  //     {
  //       date: "2025-02-10",
  //       maintenance: [
  //         {
  //           Id: "a1deX000000CIUDQA4",
  //           CCP2_Branch__c: "a1VIo0000000QQ2MAM",
  //           Maintenance_Type__c: "Scheduled",
  //           Recieving_Destination__c: "本社",
  //           Schedule_Date__c: "2025-01-31",
  //           Schedule_EndDate__c: "2025-02-13",
  //           Service_Factory__c: "自社",
  //           Service_Type__c: "車検整備",
  //           Status__c: "In Progress",
  //           Vehicle__c: "a1aIo000000HDryIAG"
  //         }
  //       ],
  //       isExpirationDate: false,
  //       countOfMaintenance: 1,
  //       isContinue: false,
  //       isMultiple: false,
  //       width:
  //         "width: calc(100% + 4px); left: 0px; border-top-right-radius: 0px; border-bottom-right-radius: 0px;",
  //       cssClass: "green-box",
  //       isStart: false,
  //       isEnd: false,
  //       serviceType: "",
  //       classForBoxes: "Calender-tile-white",
  //       isMaintenanceAvailable: "true"
  //     },
  //     {
  //       date: "2025-02-11",
  //       maintenance: [
  //         {
  //           Id: "a1deX000000CIUDQA4",
  //           CCP2_Branch__c: "a1VIo0000000QQ2MAM",
  //           Maintenance_Type__c: "Scheduled",
  //           Recieving_Destination__c: "本社",
  //           Schedule_Date__c: "2025-01-31",
  //           Schedule_EndDate__c: "2025-02-13",
  //           Service_Factory__c: "自社",
  //           Service_Type__c: "車検整備",
  //           Status__c: "In Progress",
  //           Vehicle__c: "a1aIo000000HDryIAG"
  //         },
  //         {
  //           CCP2_Branch__c: "a1VIo0000000QQ2MAM",
  //           Id: "a1deX000000CggDQAS",
  //           Maintenance_Type__c: "Scheduled",
  //           Recieving_Destination__c: "本社",
  //           Schedule_Date__c: "2025-02-11",
  //           Schedule_EndDate__c: "2025-02-13",
  //           Service_Factory__c: "自社",
  //           Service_Type__c: "3か月点検",
  //           Status__c: "In Progress",
  //           Vehicle__c: "a1aIo000000HDryIAG"
  //         }
  //       ],
  //       isExpirationDate: false,
  //       countOfMaintenance: 1,
  //       isContinue: false,
  //       isMultiple: true,
  //       width:
  //         "width: calc(100% + 4px); left: 0px; border-top-right-radius: 0px; border-bottom-right-radius: 0px;height: calc(50% - 2px); font-size:11px;",
  //       cssClass: "green-box",
  //       isStart: false,
  //       isEnd: false,
  //       serviceType: "",
  //       classForBoxes: "Calender-tile-grey",
  //       isMaintenanceAvailable: "true"
  //     },
  //     {
  //       date: "2025-02-12",
  //       maintenance: [
  //         {
  //           Id: "a1deX000000CIUDQA4",
  //           CCP2_Branch__c: "a1VIo0000000QQ2MAM",
  //           Maintenance_Type__c: "Scheduled",
  //           Recieving_Destination__c: "本社",
  //           Schedule_Date__c: "2025-01-31",
  //           Schedule_EndDate__c: "2025-02-13",
  //           Service_Factory__c: "自社",
  //           Service_Type__c: "車検整備",
  //           Status__c: "In Progress",
  //           Vehicle__c: "a1aIo000000HDryIAG"
  //         },
  //         {
  //           CCP2_Branch__c: "a1VIo0000000QQ2MAM",
  //           Id: "a1deX000000CggDQAS",
  //           Maintenance_Type__c: "Scheduled",
  //           Recieving_Destination__c: "本社",
  //           Schedule_Date__c: "2025-02-11",
  //           Schedule_EndDate__c: "2025-02-13",
  //           Service_Factory__c: "自社",
  //           Service_Type__c: "3か月点検",
  //           Status__c: "In Progress",
  //           Vehicle__c: "a1aIo000000HDryIAG"
  //         },
  //         {
  //           Id: "a1deX000000CIXRQA4",
  //           CCP2_Branch__c: "a1VIo0000000QQCMA2",
  //           Maintenance_Type__c: "Scheduled",
  //           Recieving_Destination__c: "HK Branch 1",
  //           Schedule_Date__c: "2025-02-12",
  //           Schedule_EndDate__c: "2025-02-16",
  //           Service_Factory__c: "自社",
  //           Service_Type__c: "一般整備",
  //           Status__c: "In Progress",
  //           Vehicle__c: "a1aIo000000HDryIAG"
  //         }
  //       ],
  //       isExpirationDate: false,
  //       countOfMaintenance: 1,
  //       isContinue: false,
  //       isMultiple: true,
  //       width:
  //         "width: calc(100% + 4px); left: 0px; border-top-right-radius: 0px; border-bottom-right-radius: 0px;height: calc(50% - 2px); font-size:11px;",
  //       cssClass: "green-box",
  //       isStart: false,
  //       isEnd: false,
  //       serviceType: "",
  //       classForBoxes: "Calender-tile-white",
  //       isMaintenanceAvailable: "true"
  //     },
  //     {
  //       date: "2025-02-13",
  //       maintenance: [
  //         {
  //           Id: "a1deX000000CIUDQA4",
  //           CCP2_Branch__c: "a1VIo0000000QQ2MAM",
  //           Maintenance_Type__c: "Scheduled",
  //           Recieving_Destination__c: "本社",
  //           Schedule_Date__c: "2025-01-31",
  //           Schedule_EndDate__c: "2025-02-13",
  //           Service_Factory__c: "自社",
  //           Service_Type__c: "車検整備",
  //           Status__c: "In Progress",
  //           Vehicle__c: "a1aIo000000HDryIAG"
  //         },
  //         {
  //           CCP2_Branch__c: "a1VIo0000000QQ2MAM",
  //           Id: "a1deX000000CggDQAS",
  //           Maintenance_Type__c: "Scheduled",
  //           Recieving_Destination__c: "本社",
  //           Schedule_Date__c: "2025-02-11",
  //           Schedule_EndDate__c: "2025-02-13",
  //           Service_Factory__c: "自社",
  //           Service_Type__c: "3か月点検",
  //           Status__c: "In Progress",
  //           Vehicle__c: "a1aIo000000HDryIAG"
  //         },
  //         {
  //           Id: "a1deX000000CIXRQA4",
  //           CCP2_Branch__c: "a1VIo0000000QQCMA2",
  //           Maintenance_Type__c: "Scheduled",
  //           Recieving_Destination__c: "HK Branch 1",
  //           Schedule_Date__c: "2025-02-12",
  //           Schedule_EndDate__c: "2025-02-16",
  //           Service_Factory__c: "自社",
  //           Service_Type__c: "一般整備",
  //           Status__c: "In Progress",
  //           Vehicle__c: "a1aIo000000HDryIAG"
  //         }
  //       ],
  //       isExpirationDate: false,
  //       countOfMaintenance: 1,
  //       isContinue: false,
  //       isMultiple: true,
  //       width:
  //         "width: 100%; left: 0px; border-top-right-radius: 5px; border-bottom-right-radius: 5px;height: calc(50% - 2px); font-size:11px;",
  //       cssClass: "green-box",
  //       isStart: false,
  //       isEnd: true,
  //       serviceType: "",
  //       classForBoxes: "Calender-tile-white",
  //       isMaintenanceAvailable: "true"
  //     },
  //     {
  //       date: "2025-02-14",
  //       maintenance: [
  //         {
  //           Id: "a1deX000000CIXRQA4",
  //           CCP2_Branch__c: "a1VIo0000000QQCMA2",
  //           Maintenance_Type__c: "Scheduled",
  //           Recieving_Destination__c: "HK Branch 1",
  //           Schedule_Date__c: "2025-02-12",
  //           Schedule_EndDate__c: "2025-02-16",
  //           Service_Factory__c: "自社",
  //           Service_Type__c: "一般整備",
  //           Status__c: "In Progress",
  //           Vehicle__c: "a1aIo000000HDryIAG"
  //         }
  //       ],
  //       isExpirationDate: false,
  //       countOfMaintenance: 1,
  //       isContinue: true,
  //       isMultiple: false,
  //       width:
  //         "width: calc(100% + 4px); left: 0px; border-top-right-radius: 0px; border-bottom-right-radius: 0px;",
  //       cssClass: "yellow-box",
  //       isStart: false,
  //       isEnd: false,
  //       serviceType: "",
  //       classForBoxes: "Calender-tile-white",
  //       isMaintenanceAvailable: "true"
  //     },
  //     {
  //       date: "2025-02-15",
  //       maintenance: [
  //         {
  //           Id: "a1deX000000CIXRQA4",
  //           CCP2_Branch__c: "a1VIo0000000QQCMA2",
  //           Maintenance_Type__c: "Scheduled",
  //           Recieving_Destination__c: "HK Branch 1",
  //           Schedule_Date__c: "2025-02-12",
  //           Schedule_EndDate__c: "2025-02-16",
  //           Service_Factory__c: "自社",
  //           Service_Type__c: "一般整備",
  //           Status__c: "In Progress",
  //           Vehicle__c: "a1aIo000000HDryIAG"
  //         }
  //       ],
  //       isExpirationDate: false,
  //       countOfMaintenance: 1,
  //       isContinue: true,
  //       isMultiple: false,
  //       width:
  //         "width: calc(100% + 4px); left: 0px; border-top-right-radius: 0px; border-bottom-right-radius: 0px;",
  //       cssClass: "yellow-box",
  //       isStart: false,
  //       isEnd: false,
  //       serviceType: "",
  //       classForBoxes: "Calender-tile-grey",
  //       isMaintenanceAvailable: "true"
  //     },
  //     {
  //       date: "2025-02-16",
  //       maintenance: [
  //         {
  //           Id: "a1deX000000CIXRQA4",
  //           CCP2_Branch__c: "a1VIo0000000QQCMA2",
  //           Maintenance_Type__c: "Scheduled",
  //           Recieving_Destination__c: "HK Branch 1",
  //           Schedule_Date__c: "2025-02-12",
  //           Schedule_EndDate__c: "2025-02-16",
  //           Service_Factory__c: "自社",
  //           Service_Type__c: "一般整備",
  //           Status__c: "In Progress",
  //           Vehicle__c: "a1aIo000000HDryIAG"
  //         }
  //       ],
  //       isExpirationDate: false,
  //       countOfMaintenance: 1,
  //       isContinue: true,
  //       isMultiple: false,
  //       width:
  //         "width: calc(100% + 4px); left: 0px; border-top-right-radius: 0px; border-bottom-right-radius: 0px;",
  //       cssClass: "yellow-box",
  //       isStart: false,
  //       isEnd: false,
  //       serviceType: "",
  //       classForBoxes: "Calender-tile-grey",
  //       isMaintenanceAvailable: "true"
  //     },
  //     {
  //       date: "2025-02-17",
  //       maintenance: [],
  //       isExpirationDate: false,
  //       countOfMaintenance: 1,
  //       isContinue: true,
  //       isMultiple: false,
  //       width:
  //         "width: calc(100% + 4px); left: 0px; border-top-right-radius: 0px; border-bottom-right-radius: 0px;",
  //       cssClass: "yellow-box",
  //       isStart: false,
  //       isEnd: false,
  //       serviceType: "",
  //       classForBoxes: "Calender-tile-white",
  //       isMaintenanceAvailable: "true"
  //     },
  //     {
  //       date: "2025-02-18",
  //       maintenance: [],
  //       isExpirationDate: false,
  //       countOfMaintenance: 1,
  //       isContinue: true,
  //       isMultiple: false,
  //       width:
  //         "width: calc(100% + 4px); left: 0px; border-top-right-radius: 0px; border-bottom-right-radius: 0px;",
  //       cssClass: "yellow-box",
  //       isStart: false,
  //       isEnd: false,
  //       serviceType: "",
  //       classForBoxes: "Calender-tile-white",
  //       isMaintenanceAvailable: "true"
  //     },
  //     {
  //       date: "2025-02-19",
  //       maintenance: [],
  //       isExpirationDate: false,
  //       countOfMaintenance: 1,
  //       isContinue: true,
  //       isMultiple: false,
  //       width:
  //         "width: calc(100% + 4px); left: 0px; border-top-right-radius: 0px; border-bottom-right-radius: 0px;",
  //       cssClass: "yellow-box",
  //       isStart: false,
  //       isEnd: false,
  //       serviceType: "",
  //       classForBoxes: "Calender-tile-white",
  //       isMaintenanceAvailable: "true"
  //     },
  //     {
  //       date: "2025-02-20",
  //       maintenance: [],
  //       isExpirationDate: false,
  //       countOfMaintenance: 1,
  //       isContinue: true,
  //       isMultiple: false,
  //       width:
  //         "width: calc(100% + 4px); left: 0px; border-top-right-radius: 0px; border-bottom-right-radius: 0px;",
  //       cssClass: "yellow-box",
  //       isStart: false,
  //       isEnd: false,
  //       serviceType: "",
  //       classForBoxes: "Calender-tile-white",
  //       isMaintenanceAvailable: "true"
  //     },
  //     {
  //       date: "2025-02-21",
  //       maintenance: [],
  //       isExpirationDate: false,
  //       countOfMaintenance: 1,
  //       isContinue: true,
  //       isMultiple: false,
  //       width:
  //         "width: calc(100% + 4px); left: 0px; border-top-right-radius: 0px; border-bottom-right-radius: 0px;",
  //       cssClass: "yellow-box",
  //       isStart: false,
  //       isEnd: false,
  //       serviceType: "",
  //       classForBoxes: "Calender-tile-white",
  //       isMaintenanceAvailable: "true"
  //     },
  //     {
  //       date: "2025-02-22",
  //       maintenance: [],
  //       isExpirationDate: false,
  //       countOfMaintenance: 1,
  //       isContinue: true,
  //       isMultiple: false,
  //       width:
  //         "width: calc(100% + 4px); left: 0px; border-top-right-radius: 0px; border-bottom-right-radius: 0px;",
  //       cssClass: "yellow-box",
  //       isStart: false,
  //       isEnd: false,
  //       serviceType: "",
  //       classForBoxes: "Calender-tile-white",
  //       isMaintenanceAvailable: "true"
  //     },
  //     {
  //       date: "2025-02-23",
  //       maintenance: [],
  //       isExpirationDate: false,
  //       countOfMaintenance: 1,
  //       isContinue: true,
  //       isMultiple: false,
  //       width:
  //         "width: calc(100% + 4px); left: 0px; border-top-right-radius: 0px; border-bottom-right-radius: 0px;",
  //       cssClass: "yellow-box",
  //       isStart: false,
  //       isEnd: false,
  //       serviceType: "",
  //       classForBoxes: "Calender-tile-white",
  //       isMaintenanceAvailable: "true"
  //     },
  //     {
  //       date: "2025-02-24",
  //       maintenance: [],
  //       isExpirationDate: false,
  //       countOfMaintenance: 1,
  //       isContinue: true,
  //       isMultiple: false,
  //       width:
  //         "width: calc(100% + 4px); left: 0px; border-top-right-radius: 0px; border-bottom-right-radius: 0px;",
  //       cssClass: "yellow-box",
  //       isStart: false,
  //       isEnd: false,
  //       serviceType: "",
  //       classForBoxes: "Calender-tile-white",
  //       isMaintenanceAvailable: "true"
  //     },
  //     {
  //       date: "2025-02-25",
  //       maintenance: [],
  //       isExpirationDate: false,
  //       countOfMaintenance: 1,
  //       isContinue: true,
  //       isMultiple: false,
  //       width:
  //         "width: calc(100% + 4px); left: 0px; border-top-right-radius: 0px; border-bottom-right-radius: 0px;",
  //       cssClass: "yellow-box",
  //       isStart: false,
  //       isEnd: false,
  //       serviceType: "",
  //       classForBoxes: "Calender-tile-white",
  //       isMaintenanceAvailable: "true"
  //     },
  //     {
  //       date: "2025-02-26",
  //       maintenance: [],
  //       isExpirationDate: false,
  //       countOfMaintenance: 1,
  //       isContinue: true,
  //       isMultiple: false,
  //       width:
  //         "width: calc(100% + 4px); left: 0px; border-top-right-radius: 0px; border-bottom-right-radius: 0px;",
  //       cssClass: "yellow-box",
  //       isStart: false,
  //       isEnd: false,
  //       serviceType: "",
  //       classForBoxes: "Calender-tile-white",
  //       isMaintenanceAvailable: "true"
  //     },
  //     {
  //       date: "2025-02-27",
  //       maintenance: [],
  //       isExpirationDate: false,
  //       countOfMaintenance: 1,
  //       isContinue: true,
  //       isMultiple: false,
  //       width:
  //         "width: calc(100% + 4px); left: 0px; border-top-right-radius: 0px; border-bottom-right-radius: 0px;",
  //       cssClass: "yellow-box",
  //       isStart: false,
  //       isEnd: false,
  //       serviceType: "",
  //       classForBoxes: "Calender-tile-white",
  //       isMaintenanceAvailable: "true"
  //     },
  //     {
  //       date: "2025-02-28",
  //       maintenance: [],
  //       isExpirationDate: false,
  //       countOfMaintenance: 1,
  //       isContinue: true,
  //       isMultiple: false,
  //       width:
  //         "width: calc(100% + 4px); left: 0px; border-top-right-radius: 0px; border-bottom-right-radius: 0px;",
  //       cssClass: "yellow-box",
  //       isStart: false,
  //       isEnd: false,
  //       serviceType: "",
  //       classForBoxes: "Calender-tile-white",
  //       isMaintenanceAvailable: "true"
  //     },
  //     {
  //       date: "2025-03-01",
  //       maintenance: [],
  //       isExpirationDate: false,
  //       countOfMaintenance: 1,
  //       isContinue: true,
  //       isMultiple: false,
  //       width:
  //         "width: calc(100% + 4px); left: 0px; border-top-right-radius: 0px; border-bottom-right-radius: 0px;",
  //       cssClass: "yellow-box",
  //       isStart: false,
  //       isEnd: false,
  //       serviceType: "",
  //       classForBoxes: "Calender-tile-white",
  //       isMaintenanceAvailable: "true"
  //     }
  //   ]

  //   this.getSortedCalendarData(dates);

  //   getSessionId()
  //     .then((result) => {
  //       this.sessionId = result;
  //       this.initializeCometD();
  //     })
  //     .catch((error) => {
  //       console.error("Error fetching session ID: " + error);
  //     });
  //   // Simulating fetched data
  //   // this.processServiceDates(this.maintanceHistoryData);
  // }

  // initializeCometD() {
  //   loadScript(this, cometdlwc).then(() => {
  //     var cometdlib = new window.org.cometd.CometD();
  //     // console.log('cometdlib', cometdlib);
  //     // console.log('window.location.protocol', window.location.protocol);
  //     // console.log('window.location.hostname', window.location.hostname);
  //     // console.log('this.sessionId', this.sessionId);
  //     //Calling configure method of cometD class, to setup authentication which will be used in handshaking
  //     cometdlib.configure({
  //       url:
  //         window.location.protocol +
  //         "//" +
  //         window.location.hostname +
  //         "/cometd/59.0/",
  //       requestHeaders: { Authorization: "OAuth " + this.sessionId }, // you need get the sessionId from Apex
  //       appendMessageTypeToURL: false,
  //       logLevel: "debug"
  //     });

  //     cometdlib.websocketEnabled = false;

  //     cometdlib.handshake(function (status) {
  //       if (status.successful) {
  //         // Successfully connected to the server.
  //         // Now it is possible to subscribe or send messages
  //         // console.log("Successfully connected to server");
  //         cometdlib.subscribe("/event/CCP_Notification__e", function (message) {
  //           // console.log("subscribed to message!" + message);
  //         });
  //       } else {
  //         /// Cannot handshake with the server, alert user.
  //         console.error("Error in handshaking: " + JSON.stringify(status));
  //       }
  //     });
  //   });
  // }

  // disconnectedCallback() {
  //   // this.unsubscribeFromPlatformEvent();
  // }

  // @api vehicleChessis;
  // months = [
  //   { name: "Jan", hasService: false, className: "service-marker" },
  //   { name: "Feb", hasService: false, className: "service-marker" },
  //   { name: "Mar", hasService: false, className: "service-marker" },
  //   { name: "Apr", hasService: false, className: "service-marker" },
  //   { name: "May", hasService: false, className: "service-marker" },
  //   { name: "Jun", hasService: false, className: "service-marker" },
  //   { name: "Jul", hasService: false, className: "service-marker" },
  //   { name: "Aug", hasService: false, className: "service-marker" },
  //   { name: "Sep", hasService: false, className: "service-marker" },
  //   { name: "Oct", hasService: false, className: "service-marker" },
  //   { name: "Nov", hasService: false, className: "service-marker" },
  //   { name: "Dec", hasService: false, className: "service-marker" }
  // ];

  // isTooltipVisible = false;
  // hoveredServiceDate = "";
  // tooltipClass = "tooltip hidden"; // Initially hidden

  // serviceDates = [];
  // serviceCosts = [];

  // @track maintanceHistoryData = [];

  // //   , { vehicleId: "$vehicleId" }
  // @wire(getDataFromDLO, { key: "$vehicleChessis" })
  // handledata(result) {
  //   const { data, error } = result;
  //   if (data) {
  //     // console.log("getDataFromDLO data:- ", data);
  //     this.maintanceHistoryData = data;
  //     this.processServiceDates(data);
  //   } else if (error) {
  //     // console.error("geting from DLO api: ", error);
  //   }
  // }

  // processServiceDates(data) {
  //   // Extract service dates from data
  //   this.serviceDates = data.map((item) => {
  //     return item.srv_dt__c.split(" ")[0]; // Only keep the date part (DD/MM/YYYY)
  //   });

  //   // Mark the months with services
  //   this.updateServiceMonths();
  // }

  // updateServiceMonths() {
  //   let costToShow = 0;
  //   this.months = this.months.map((month) => {
  //     const serviceForMonth = this.serviceDates.find((service) => {
  //       costToShow = this.maintanceHistoryData.filter((x) => {
  //         let cost = 0;
  //         if (x.srv_dt__c.split(" ")[0] === service) {
  //           cost = x.x_bill_amount_total__c;
  //         }
  //         return cost;
  //       });
  //       const serviceDate = new Date(service.split("/").reverse().join("/")); // Convert to YYYY/MM/DD
  //       return this.getMonthName(serviceDate) === month.name;
  //     });
  //     if (serviceForMonth) {
  //       return {
  //         ...month,
  //         hasService: true,
  //         className: "service-marker marked",
  //         serviceDate: serviceForMonth, // Store the service date,
  //         costToShow: costToShow[0].x_bill_amount_total__c
  //       };
  //     }
  //     return month;
  //   });
  // }

  // getMonthName(date) {
  //   const monthNames = [
  //     "Jan",
  //     "Feb",
  //     "Mar",
  //     "Apr",
  //     "May",
  //     "Jun",
  //     "Jul",
  //     "Aug",
  //     "Sep",
  //     "Oct",
  //     "Nov",
  //     "Dec"
  //   ];
  //   return monthNames[date.getMonth()];
  // }

  // getTooltipShow() {
  //   return this.showTool === true;
  // }

  // handleMouseOver(event) {
  //   const arrow = event.target; // Directly get the arrow element
  //   const monthItem = arrow.closest(".timeline-item");
  //   const monthName = monthItem.dataset.month; // Get the month name
  //   const serviceMonth = this.months.find(
  //     (month) => month.name === monthName && month.hasService
  //   );

  //   if (serviceMonth) {
  //     this.hoveredServiceDate = serviceMonth.costToShow;

  //     // Get the arrow's position relative to the document
  //     const arrowRect = arrow.getBoundingClientRect();
  //     const tooltip = this.template.querySelector(".tooltip");

  //     // Calculate the position
  //     tooltip.style.left = `${arrowRect.left + arrowRect.width / 2 - tooltip.offsetWidth / 2 - 380}px`;
  //     //   tooltip.style.top = `${arrowRect.top + window.scrollY - tooltip.offsetHeight - 5}px`; // Adjust top value as needed

  //     this.tooltipClass = "tooltip visible";
  //   }
  // }

  // handleMouseOut() {
  //   this.tooltipClass = "tooltip hidden"; // Hide tooltip on mouse out
  //   // this.hoveredServiceDate = ''
  // }

  // //   navigationPoc(event){
  // //    window.focus();
  // //    setTimeout(() => {
  // //     window.focus();
  // //     console.log('2focuesdwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');

  // //    }, 3000);
  // //    this.newFun();

  // // const elm = this.template.querySelector('nnnn');
  // // elm.click();

  // //   }

  // navigationPoc() {
  //   // console.log('hi!!');
  //   const newW = window.open(
  //     "https://www.w3schools.com",
  //     "_blank",
  //     "noopener,noreferrer,width=800,height=600,resizable=yes,scrollbars=yes"
  //   );

  //   if (newW) {
  //     // eslint-disable-next-line @lwc/lwc/no-async-operation
  //     newW.blur();
  //     setTimeout(newW.focus, 0);
  //   } else {
  //     // eslint-disable-next-line no-alert
  //     alert("Please allow popups for this website");
  //   }
  // }

  // //   getSortedCalendarData(dates){
  // //     if (!dates || dates.length === 0) return [];
  // //     console.log('dates',dates);

  // //     let modifiedDates = [];
  // //     let prevList = [...dates[0].maintenance];

  // //     modifiedDates.push({ ...dates[0] });

  // //    for (let i = 1; i < dates.length; i++) {
  // //         let currentDate = { ...dates[i] };
  // //         let newMaintenance = [];
  // //         let usedIndices = new Set();

  // //         prevList.forEach((prevEvent, index) => {
  // //             let matchedEvent = currentDate.maintenance.find(event => event.Id === prevEvent.Id);
  // //             if (matchedEvent) {
  // //                 newMaintenance[index] = matchedEvent;
  // //                 usedIndices.add(currentDate.maintenance.indexOf(matchedEvent));
  // //             } else {
  // //                 newMaintenance[index] = this.createDummyEvent();
  // //             }
  // //         });

  // //         currentDate.maintenance.forEach((event, idx) => {
  // //             if (!usedIndices.has(idx)) {
  // //                 newMaintenance.push(event);
  // //             }
  // //         });

  // //         currentDate.maintenance = newMaintenance;
  // //         modifiedDates.push(currentDate);
  // //         prevList = [...newMaintenance];
  // //     }

  // //     console.log('modifiedDates',JSON.stringify(modifiedDates));
  // //     return modifiedDates;
  // //   }

  // //  createDummyEvent() {
  // //     return {
  // //         Id: null,
  // //         CCP2_Branch__c: null,
  // //         Maintenance_Type__c: null,
  // //         Recieving_Destination__c: null,
  // //         Schedule_Date__c: null,
  // //         Schedule_EndDate__c: null,
  // //         Service_Factory__c: null,
  // //         Service_Type__c: null,
  // //         Status__c: null,
  // //         Vehicle__c: null
  // //     };
  // // }

  // /*
  // Below two method are for calendar
  // Just pass dates(30 or 31) of any vehicle it will arrange the dates in proper order,
  // and append dummy data for proper positioning of events.
  // */
  // getSortedCalendarData(dates) {
  //   if (!dates || dates.length === 0) return [];

  //   console.log("dates", dates);

  //   let modifiedDates = [];
  //   let prevList = [...dates[0].maintenance];

  //   modifiedDates.push({ ...dates[0] });
  //   for (let i = 1; i < dates.length; i++) {
  //     let currentDate = { ...dates[i] };
  //     console.log("currentDate.date", currentDate.date);
  //     let newMaintenance = Array(prevList.length).fill({
  //       Id: null,
  //       CCP2_Branch__c: null,
  //       Maintenance_Type__c: null,
  //       Recieving_Destination__c: null,
  //       Schedule_Date__c: null,
  //       Schedule_EndDate__c: null,
  //       Service_Factory__c: null,
  //       Service_Type__c: null,
  //       Status__c: null,
  //       Vehicle__c: null
  //     });
  //     // console.log('newMaintenance first', [...newMaintenance])
  //     let usedIndices = new Set();

  //     let matchedCount = 0;
  //     let lastMatchedIndex = -1;

  //     // Step 1: Try to place matched events at their previous positions
  //     prevList.forEach((prevEvent, index) => {
  //       let matchedEvent = currentDate.maintenance.find(
  //         (event) => event.Id === prevEvent.Id
  //       );
  //       if (matchedEvent) {
  //         newMaintenance[index] = matchedEvent;
  //         usedIndices.add(currentDate.maintenance.indexOf(matchedEvent));
  //         matchedCount++;
  //         lastMatchedIndex = index;
  //         // console.log('newMaintenance if', [...newMaintenance])
  //       } else {
  //         newMaintenance[index] = this.createDummyEvent();
  //         // console.log('newMaintenance else', [...newMaintenance])
  //       }
  //     });

  //     currentDate.maintenance.forEach((event, idx) => {
  //       if (!usedIndices.has(idx)) {
  //         // console.log('event', event,idx, lastMatchedIndex)
  //         // console.log('newMaintenance', newMaintenance)
  //         lastMatchedIndex = lastMatchedIndex + 1;
  //         // while ([...newMaintenance[insertIndex]]?.Id !== null || undefined) {
  //         //       insertIndex++;
  //         //   }
  //         newMaintenance[lastMatchedIndex] = event;
  //         // console.log('newMaintenance2', newMaintenance)
  //       }
  //     });

  //     // Remove trailing dummy events if not required
  //     newMaintenance = newMaintenance.filter((event) => event !== null);

  //     currentDate.maintenance = newMaintenance;
  //     modifiedDates.push(currentDate);
  //     prevList = [...newMaintenance];
  //   }

  //   console.log("modifiedDates", JSON.stringify(modifiedDates));
  //   return modifiedDates;
  // }

  // createDummyEvent() {
  //   return {
  //     Id: null,
  //     CCP2_Branch__c: null,
  //     Maintenance_Type__c: null,
  //     Recieving_Destination__c: null,
  //     Schedule_Date__c: null,
  //     Schedule_EndDate__c: null,
  //     Service_Factory__c: null,
  //     Service_Type__c: null,
  //     Status__c: null,
  //     Vehicle__c: null
  //   };
  // }

  base64ToBlob(base64, contentType = "application/pdf") {
    const byteCharacters = atob(base64);
    const byteArrays = [];

    for (let offset = 0; offset < byteCharacters.length; offset += 512) {
      const slice = byteCharacters.slice(offset, offset + 512);
      const byteNumbers = new Array(slice.length);

      for (let i = 0; i < slice.length; i++) {
        byteNumbers[i] = slice.charCodeAt(i);
      }

      const byteArray = new Uint8Array(byteNumbers);
      byteArrays.push(byteArray);
    }

    return new Blob(byteArrays, { type: contentType });
  }

  connectedCallback() {
    this.getImagesAsBase64Fun();
  }

  // get pdfUrl() {
  //   console.log("base 64 data IN PDF", `data:application/pdf;base64,${this.base64Pdf}`);
  //   // const byteCharacters = atob(this.base64Pdf);
  //   // const byteNumbers = new Array(byteCharacters.length);
  //   // for (let i = 0; i < byteCharacters.length; i++) {
  //   //   byteNumbers[i] = byteCharacters.charCodeAt(i);
  //   // }
  //   // const byteArray = new Uint8Array(byteNumbers);

  //   // // Create a Blob from the byte array
  //   // const blob = new Blob([byteArray], { type: "application/pdf" });

  //   // // Generate a URL for the Blob
  //   // return URL.createObjectURL(blob);

  //   return `data:application/pdf;base64,${this.base64Pdf}`;
  // }

  get pdfUrl() {
    console.log("Base64 data IN PDF", this.base64Pdf);

    if (!this.base64Pdf) return null; // Handle the case where data is missing

    try {
      // Decode base64 string to binary data
      const byteCharacters = atob(this.base64Pdf);
      const byteNumbers = new Array(byteCharacters.length);

      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }

      const byteArray = new Uint8Array(byteNumbers);
      const blob = new Blob([byteArray], { type: "application/pdf" });

      // Generate a secure Blob URL
      return URL.createObjectURL(blob);
    } catch (error) {
      console.error("Error generating PDF URL:", error);
      return null;
    }
  }


  @track base64Pdf = `JVBERi0xLjQKJcOkw7zDtsOfCjIgMCBvYmoKPDwvTGVuZ3RoIDMgMCBSL0ZpbHRlci9GbGF0ZURlY29kZT4+CnN0cmVhbQp4nD2OywoCMQxF9/mKu3YRk7bptDAIDuh+oOAP+AAXgrOZ37etjmSTe3ISIljpDYGwwrKxRwrKGcsNlx1e31mt5UFTIYucMFiqcrlif1ZobP0do6g48eIPKE+ydk6aM0roJG/RegwcNhDr5tChd+z+miTJnWqoT/3oUabOToVmmvEBy5IoCgplbmRzdHJlYW0KZW5kb2JqCgozIDAgb2JqCjEzNAplbmRvYmoKCjUgMCBvYmoKPDwvTGVuZ3RoIDYgMCBSL0ZpbHRlci9GbGF0ZURlY29kZS9MZW5ndGgxIDIzMTY0Pj4Kc3RyZWFtCnic7Xx5fFvVlf+59z0tdrzIu7xFz1G8Kl7i2HEWE8vxQlI3iRM71A6ksSwrsYptKZYUE9omYStgloZhaSlMMbTsbSPLAZwEGgNlusxQ0mHa0k4Z8muhlJb8ynQoZVpi/b736nkjgWlnfn/8Pp9fpNx3zz33bPecc899T4oVHA55KIEOkUJO96DLvyQxM5WI/omIpbr3BbU/3J61FPBpItOa3f49g1948t/vI4rLIzL8dM/A/t3vn77ZSpT0LlH8e/0eV98jn3k0mSj7bchY2Q/EpdNXm4hyIIOW9g8Gr+gyrq3EeAPGVQM+t+uw5VrQ51yBcc6g6wr/DywvGAHegbE25Br0bFR/ezPGR4kq6/y+QPCnVBYl2ijka/5hjz95S8kmok8kEFl8wDG8xQtjZhRjrqgGo8kcF7+I/r98GY5TnmwPU55aRIhb9PWZNu2Nvi7mRM9/C2flx5r+itA36KeshGk0wf5MWfQ+y2bLaSOp9CdkyxE6S3dSOnXSXSyVllImbaeNTAWNg25m90T3Rd+ii+jv6IHoU+zq6GOY/yL9A70PC/5NZVRHm0G/nTz0lvIGdUe/Qma6nhbRWtrGMslFP8H7j7DhdrqDvs0+F30fWtPpasirp0ZqjD4b/YDK6Gb1sOGVuCfoNjrBjFF31EuLaQmNckf0J9HXqIi66Wv0DdjkYFPqBiqgy+k6+jLLVv4B0J30dZpmCXyn0mQ4CU0b6RIaohEapcfoByyVtRteMbwT/Wz0TTJSGpXAJi+9xWrZJv6gmhBdF/05XUrH6HtYr3hPqZeqDxsunW6I/n30Ocqgp1g8e5o9a6g23Hr2quj90W8hI4toOTyyGXp66Rp6lr5P/05/4AejB2kDdUDzCyyfaawIHv8Jz+YH+AHlZarAanfC2hDdR2FE5DidoGfgm3+l0/QGS2e57BOsl93G/sATeB9/SblHOar8i8rUR+FvOxXCR0F6kJ7Efn6RXmIGyK9i7ewzzMe+xP6eneZh/jb/k2pWr1H/op41FE2fnv5LdHP0j2SlHPokXUkH4duv0QQdpR/Sj+kP9B/0HrOwVayf3c/C7DR7m8fxJXwL9/O7+IP8m8pm5TblWbVWXa9err6o/tzwBcNNJpdp+oOHpm+f/ub0j6JPRX+E3EmC/CJqhUevQlY8SCfpZUj/Gb1KvxT5A/lr2Q72aWgJsBvYHeyb7AX2I/ZbrJLkewlfy5uh1ceH4aer+e38Dmh/Ce9T/Of8Vf47/kfFoCxRVip7lfuVsDKpnFJ+rVrUIrVCXa5uUXeoUUSm2nCxocPwiOFxw3OGd4z1xj6j3/gb09Wma83/dLbs7L9N03T/dHh6ArlrRiZdCU98lR5A3h9FDH4Aj/4QFp+mdxGFHFbAimH3atbK2tgm9il2GfOwq9n17O/Yl9k97AH2LawAa+Am2O7gjbyDu7iHX8uv57fwo3gf59/nP+Gv8DOwPEuxKw5lubJR2aFcqgxhDUHlgHItPHub8pjykvKy8qbyG+UMopalLlZD6pXq3erD6lH1R4ZPGgbxfsBw0jBl+JHhA8MHRm7MMeYZK42fMT5i/KXJaFppajfdaPoX03+Y/SyPlcFybX614NnYg4v5YzxdPcjOAJHPVErGyh2IQwd2xX9QgzKNuCSJediWwbPVNMFpdKph8AfZCaplL9BBI1dQidXTFGG/4KfV5/lF9GPWw7LVh5Uhww94AT2OanSYP81PsPV0lNfzS/i9CrE32CP0BvL9CrqDXc4C9Dg7w9awz7M6dpD+hWcqHexaqo8+wFUWxzaydwgW0FVqH33646sgW02/oLemv6omqp9DfZqkuxDRb9Br7FH6MzNE30Z1U1CNXKgyNyPfryNR9XZinx3EfsxGBRkwvkRHxYliqjOuU6+kd+g/6S3DcWTUelTSN6e96lfVX0XrouXYYdhl9Aj2XT9djB3zBrLkGYzF6DLs9HjUkmrs6nbaQX30eVS926Lh6L3Ra6L7oz76R/D+mS1jf2Zj2BGT4Kin7+H9RfoZuwn78OL/3ikw3UdT9FtmZYWsGvvhjGGf4bDhMcNRw7cNLxqXw9vX0j3I6F8im+OxAjf9iH5Lf2JmxCabllEN7F0F27togHcrz1ATyyE/9mwJ6vh6fSUBSLka3rsX+/kZ7I13UCcuo2/TK4yzLKzIDf1myGmDn3eB+iFE8Bo2AUwfqnYZ/Q7rTmKreBD6nJB0F6rWFGz6Bf0a3o5Ku5ahLjSzSyDrT/Qp6oOGldTOxhGBJ2k1Kmuz8k/w91JmofVsCfs6+HqwQ5Mon1YbfsU4LZveHF3FvcozOGOiwI/h9Mqli9heWJGMdZylDLaFaqe3wYaXiZyNnc6GdRfVr12zelVdbc2K6uVVlRXlyxxlpSXFRYVL7UsKNNvi/LzcnGxrVmZGelpqiiU5KTFhUXyc2WQ0qApntKzF3tqjhYt6wmqRfcOGcjG2u4BwzUP0hDWgWhfShLUeSaYtpHSCcveHKJ0xSucsJbNo9VRfvkxrsWvhF5vt2iTbsbUL8C3N9m4tfEbCmyR8WMKJgAsKwKC1WPubtTDr0VrCrfv6R1t6miFufFF8k73JE1++jMbjFwFcBCicZfePs6x1TAI8q2XNOCdzIowK59ibW8LZ9mZhQVgpbHH1hdu3drU05xYUdJcvC7Mmt703TPb14WSHJKEmqSZsbAqbpBrNK1ZDN2njy6ZGb560UG+PI6HP3ue6rCusuLqFjhQH9DaHs6583To3hPDUpq7r58/mKqMtVq8mhqOj12vhqa1d82cLxLW7GzLAywtbe0ZbofpmOLGtQ4M2fl13V5hdB5WaWIlYVWx9HnuLwPR8RgvH2dfb+0c/04PQ5IyGadv+gkhOjvNY9DTltGijnV32gnBDrr3b1Zw3nk6j2/ZPZDu17IUz5cvGLSkxx44nJetAQuJ8wDM7JyFJLqC2bbOeZcIi+0YkRFhza7Cky441rRIXzyoada8CGV7dDFzhPkTEG45r6hm1rBF4wR82FFrs2ugfCRlgP/P2QoxLxxgLLX8kAYo8mU01zM/AYYcjXFYmUsTUhJjCxnVyXFu+bN8kX2n3WzR0cB+1w7eu7jWVcH9BgQjwTZNO6sUgfGhrV2ysUW9uhJyVju4w7xEzUzMzGdvFzKGZmVn2Hjsy+ah8EMgIm4tm/yVbMtNa+teEWebHTHti820d9ratO7q0ltEe3bdtnQtGsflVs3M6FE5r6lJyuQ7xXEXOIikvmyUWg66EsFqIf0aZ1H1hBUkpEUxrDVt6NsSu3fEFBR/JM2kyz2OajL4juGQ3x6ZbGV7jWDheu2C8wLqEUQX2qkW8rXPH6Gj8grlWFKDR0Va71jraM+qajB7qtWsW++gx/jB/eNTf0jMT0Mno8Ztyw603d2MR/WwNkpXT+nE7u2HruJPd0LGj65gFT283dHZFOONNPeu7x5dirusYbkWcEstnsWKkiRG1MSR6hJvlVO4xJ9EhOatKhBy7JxlJnHkGx8g9yWM4i8ThVY7bFBF8A9449U20/ihn00bTJG9wppFBnVYo3qROM8o2Gw3TXHmaFVEcbnatZHVY3qs/W7/Z8m79prP11ADY8gEuy6sKUgpSCnFhuIH4QFOmPnAa6C+kqVPQhScYMrjwnGUhGx10rigxlMRfnOVRPQmGsqzVWRsyuzP7Mw2rs1bmXp97t+GuRQZbSiEjnpZamGwxZxcfMTHTZHRqIm5RDUy82Zl2qIBpBVUFvCAlVSPNUmXhlkl+04S2vMPqgGk7hW2bLDv3vufYu+mMNLJB2kg797KdaQXVWZmZqRnpuBfE217AUlZU163jtTVFRcVF9jt4/lM9V032lNft3nRN79fPvsxKXv1c3YZd9fUDHeueMBzPK3pu+s0fPnHNmLutzKY+90FtUuolLzz22JO7U5PEs/ct0d+oHbivy6R7nVmfStmTcpdBiTNmG+t5fUobb0t5k5uSJ3nQmaIuyqT4jPT0+DhjWnpRRgZNslJnUqZTW1pzJJNFM1lmjhWLdmYuWVpz2Dpm5X7rO1b+eyuzxi8qijOLqWTQjpnZO2Zmzs5qqJdr3zvsEKvfjNUPO95D23Sm3iIjVW+BFxrOCC+wnQW1RqN9SVFRLaKWnpm5onrlSgEqm9c84738sU+ybNu2hg3DZSz7vu29n37sLj42bT3tWbsl9Dqb+svPxToP4H73y+o6KmZrj1EpjNmZEt9gMBoTMoyZCTVKjbnGWmNv5i3mFmuzPUFTKks74npKD5XeV/p148OmhxKeMD6REC49VXq6NIlKK0vbMXGy9LVSY6kzJ6+mAeNDctJgKlBNOfmZcFkk3lQgPLdYNVlSUopz8/KKiuMZGZMtRakpzh21PSnMl8JSJnmrMzkntyg/DzhfHuvJY3nAHS1EdBl8HCEqFsmUHNcgeudK2F0M0mJnI1o92tLimmLnmotqKotfKn6tWEkuthUfKlaoWCuuKo4Wq8XZJb+K+Vq4OPZCtp2Bl9/budeBRHtv707RwefS6+LdcKbhDEtJXU1oy6vYsGPvToTBkVaQsXJFdWbWSnnNzEAIapCDS4xGCRbNgAeYctPU7ruqWh+4LPRASf70m/nFW9f2V0y/ubhhZWN/+fSbatFtj3Zu396567LmL5/t5ru+WlG/4aa7pjlvvWfHstZr7z77AWKWNL1V3YbcTGM1R1NLDCxtMnraaU1IrjFnJibXmMTFKC6GTOC4cI4tZ00NgqomLkoyWjilGdU0rioKg9vTeizMMsmOOFMXJSdWJpWQllGV0ZOhvJPBMoR/lxTViN6Zmre4JiMrK0ddrTit2TUHFaZMsmJnHJcjVD8xSsXTiTNvZY1GVagW2enfGYs52LHpbDau+Gc9u7nF0/xrh2Pv8CbLu69Tw5mdlQ3StSx1dYr0a+pqAKYki9joDibjsrMtbOloC69BxY+oFjoefYdY9J1xBc/veHXjRDlGhuhvnEmJKQ1plrRsXFKtDQacIRMYiD6CcUxWd1pBWloBMyUp9iXFxWLL1CUxx/T7zD59Y1Nh06cOtm/dnL2+tvfT2WrR2ST+hw/4sZ29Fy1J+UVioFvUwDvxLPg+amAy7rdHnIVGw7H0Y1blYgPbY/iJgaemFCYmJVGupRAuSSZz5jlVL9OWX5Xfk+/PP5RvyLckayzmLFH48hYWvtm6J6pe6urKudq3IqVAQ/HLSDeKymfP5nLj14i6dyf7V5a07cBjvV/a/JnvP/vAkX1Nn95QO2Y4nlnw6pHrJ70pGWd/qj433VPR29jenxiPbPoS1nMt1hNHw84Gs0E1GgpNmrnKfNL8mlmtNB82c7OZFFWsJ47MpgbjFjyKb1Nw8vAcbVHVIr5IjZu/iPj5i0D9eg8ABnPL2LkXvWKw1GM1WEhGgWxfUs6cXcv7zt5rOP7+9IPvn71NVCcrHP5rw8uowpPO6pUqK1M1i5bSrR6yGszqSSvPyEzh6amZKUlpyWRJSmNk4elx5uRFbNeiKAwTZSbeyFKSY4VYVh2c13jYFomPkr2iwbzF3G5WzCWWypRdKTxlkqnOxKS0Ip6+i8YypzJ5JkL3ZFxCTWZ21hXHuJfk0hx76zeJ0/KDnfXv7sx+naxYm1gVWgMuq6uT8UJ5EMUhbUVtjSgLWSZRBDIyVmTYURLs1ntX3x26IlDUtO6i2n/+5+k371WL2r9wbcfS71hWb2179YOnlI0i126Hsd9AbMTZPnKM4rAPG1DnnHHtcfxQXDhuKu5U3O/jDLa4nriDcWNAGBSjCQe/kkzMSafwxKjQTtwiGA1GkxrPTUVMFXs5rmBpjZpt1o8ah34LIAOEJcjQyOhgAcOONJjL0G5n2dNvsmz1SaZOf/CXT6hFOEDYPAs7xBaccpYK+wztBn7IEDZMGU4Zfm8w2Aw9hoOGMSAMMAY3JVwpYjRjCWWr51ii614R02s4/udWeKMRZ3Ixzqp0ymNfO0aW6PvO1kWr7477SuJdlkcMD8efiDuROJljNqezDfxiY2v8lsWPJD5pfDLnu/HfS/hJ/CsJ75v+lJiYl5yX4czNr8lwJqXUJGeczHgpQ5GFLnlxg+yTstDzW5wJyUmp7Uk9STzJmspEFmTn1rAVqcLsiXytRvZLSmO9ozzWW/Nk70xOSq4ZE/flFpi9KzUVmTehLkq1igxcushEBawyo2BLEkvKqVy8a7Fv8X2L1cXJBWYnirY5O9/bGPPGpjNy+2w68y6KwBkUOWe61VmS3mB1Lk7GJdeCS15KgyxqDWdlEUyFEaBIFcaASPagE31khhTnnSyEkoEwgeNMzGeJLjwRF79ODhsLGhwk6F93oCjvlOqTnPBSklCaJNQnOeEskkJRnBwOHKP1uAtD8HbupZ0OhiPHrhUX1VpoRTUpBfL+JE0chiZjFv8zs65868j0767zsvSXz7BU41mncrVr/Y5i5YpLLquvZ2xb5Vfuf+K2V5kZ1fm70898/qYNbODKg01NAfkxmPiI79d7nvlx/8ldyfV/NGeb5adDD/yqfu5Tf5reavwyqgdDbWMzH58RmdZNb6amuQ/UPvQBU4IRKMN36Q71V3SLKZ8OqAFK4qtx53sJ3Qncl/hjZMX4dtEw1wielfQ4s7H/5JN8UtGUIeV/qw1qyPBZXXoClSANxIsjISppO+65Nlt82AgCu0u9ksTduzRYXhXJFy9HiuTCnaEOK9TFLDqsUjrr12EDWdnndNgI+A4dNtF32Dd02ExF3K/DcTTK79LhePU5RdPhRdRr+qUOJ9Buc7MOJxqPmh/T4SS6LPnTs347mHxch+E2y2od5qRa1umwQsss63VYpXjLkA4bKMFyhQ4bAV+rwybqtRzWYTOlWf6gw3HUkmLQ4XjuSvmEDi+i5WmPz35btiLtFzqcqOxIT9bhJKrI8sISpgqvJ2V9SYdVysl6UMIG4OOzTuqwSplZ35ewEXhj1ms6rFJq1hsSNom4ZP1JhxGLrKiEzcAnWNN0WCWr1SbhOBFfa50OI77ZtToMOdkNOoz4Zl+sw5CZfZ8OI77ZEzqM+Gb/ow4jvtm/0mHEN+dhHUZ8c17UYcQ391M6jPhq2TqM+Gqf1WHEV/tfOoz4Ft8p4Xjhq+J/12H4qji2xkXAp5Zk67BKi0scEk4QaynZqMOwv2SrhJNE5pd4dFilvJKQhC1Szm06LOR8TcJpwuclz+owfF7yXQmnC3tKfqbDsKfkTQlnAJ9eynRYJa00Q8KZgr60VodBX9ok4WxJv1OHBf1eCeeKHCi9TYeRA6X3SDhf2FM6rsOwp/QpCdsk/fd1WNC/LOGlIgdK39Jh5EDpHyVcJvxTlqjD8E9ZzM5yUQnKSnVYnYHN0v+zMOwvk/ljlusq26rDAr9LwAkx+v06LPDXS1jGpex+HRZ6H6VO2k9+8tBucpEbvUaPonVSv4Q3kY+G0II6lYaK6aNhwOLqAt4rKTRgBsBfAahZ4l3/Q0mVs5Zp1IGZAQrN0gSA24g+pm85rca7isp1qFpiG8ExgH4bePbAhqDk2gZ5AbRh2odrH6iGMe8C5Xqpo+8cO9fMo9FmqdbQJVJKYNbqFdBahbeGKr8JWDdmfZj3wbNBKj2vlI+SMUdbPs+uznn4b0nPCr/1QcYg+mG6HDih7b/vcw1YD7zlhU1BaZvwkYaxoAnqUrcjHhq1S36NiqS+Tbhuge7d0vcu0As+D6QKb49ITiGt4jw2xeLsg15hkx+0+z+SyiPzS9CNSKv2zOr16tlbLqPso17d6s1ypl960QVrls3aPixnvDJTO3ANSatjEYll1SrkUpO0JCi9POO3Ydiigcql52Iso7zS930yw0TODUld8+Pu1mW5pG2Cc1BKFHb3Q/+glBjzviatdkl9bj0asRlhdUCPh0uuMca3fzb+Xj3b/XoEPdI3AZmNsdXNRMil2x+S2jSpYb5VM5EXvhHjESm7f142CFqflBXTPYOPeTuoe8StZ2rgHLogZHqkV7zoY7LdOiYkPS0yai6nfXLnDkuPDkh+YamI56DONaPBLfn36Vq9+kpj+1FImPPCblAKaTHsnF+9und9+kq8kj4kR3NRDcgsHZDWnT8nZmprYHYtYm5QypuTIerF5bq1Lt3/bln1NH2XzvisT+reI7ExfrHDvHoM++W+8+s54sNV7Oh9urdjEuaqvUvGKpYdmvShW1+/V0ZtQNL45d6LZeOQ5IytZH52e2czS+z8K/TIDEprRG7u0/dWrO4MzNoxKEdz2Rv80IkU+ND63LqOXikhJD3dtyA3PbQX+BnPitx2z65wt8xtTebAFdK3AZl3wdl6Eou6sD2234N61YjtpoCeZXPVMzY7KCPioislf8xqIdctZ+cyLaa9T3rLL3fJ/tlVzOgekjVTzLukJ4Z1HWIPxbwYlPwzFs9I98scGpR1c8a2Cnn2BTG3BmdqJeSKd4Wkml9hK2R1GgRFv9xLA4AGAQ3JCHnkKEC7ZA7EIl4xS/l/V8OIzJgYrWeels2o9J0491vRmpB5At4CrDgBWnH9pMS3ANOBq8jNi3EStOC9SWI7KRFPU6J1ymwKnCfXtFl8bJ/EPOrXfT6Xo3/dKTYXmZmKPBPnXjm7H/ShWZ3u2doWy+e582h+tYxVjrk6Gtu/Xr1mBvQ9vUdK8czWRLFbu3VtYnfv02tp7+xpFNMZ/BjPzNTOkdnq5NF3nGc2p4dl/Qjq+3m3no/n89fMLhQe88yTMreLz9XXp5+AIgN7ZWWMWd2rR2ZIl3y+CBXLVS30VKwin5sV52qeqW2iirnkvagLWgd0bwf0GvJRuoX3twMzV2f3nxMLj36XMf+eK1a9XdIiv/SsV7/T+Wtirum5ODSvts3oFZWkT3raO+8UGZ53r7xslnp4Xt7Ond0f7ylh3aCUP5NXvgXyRmT8L5fRnH8fOlMf5yh9oI3doYakx4X8/tn1xOyan92DekWN+T+2q/x6fsxV3oU59HErmsuPjXLt50Zu5t5LnDke/Q4ttprY/Z5bRnXoQzEY/pC/5yQH5N1qSN71x86hffLeaITm313919GfkTes3/959Wee893FnRvHmLfm7ljdUua5+3gmYq4P+Xr332TtnJfP1bDwvF9okUe/iw3i7JmRIJ5PGin2JFCCe/gaqsPzl4brcozK8XxVI5+yxKcj26lNp6zC7HLM1OhwHZ7G6iTXSqrFs4BoQvrfdtb990/GmbnKD3lv9jzs3O/37Ha5PdqjWme/R9vkG/IFgdKafMN+37Ar6PUNaf4Bd4XW7Aq6/guiSiFM6/ANhAQmoG0cAt/y1aurynGprtAaBwa0bd49/cGAts0T8Azv8/Q1DntdA+t9A30zMtdIjCZQay7xDAeE6BUVVVVaySave9gX8O0Ols6RzKeQ2HIpq1PCj2idw64+z6Br+HLNt/tjLdeGPXu8gaBn2NOneYe0IEi3d2jtrqBWpHVu0rbs3l2huYb6NM9AwDPSD7KKWUlYs2/PsMvfv38+yqM1D7tGvEN7BK8X7i3Xtvl6IXqz193vG3AFlgnpw16316V1uEJDfVgIXLWqusk3FPQMCtuG92sBF7wIR3l3a32egHfP0DIttnY3qFxeTA76hj1af2jQNQTzNXe/a9jlxjIw8LoDWIdrSMPcfrF+L9zuxwI9bk8g4IM6sSAX5Ifc/ZpXFyUWHxryaCPeYL90w6DP1ye4BQyzgzDEDacGZnDBEc9Q0OsBtRtAaHh/hSY97dvnGXYh3sFhjys4iCnB4A4h5gGhTMTRMyxN2B0aGAAobYX6QR+UeIf6QoGgXGoguH/AM98TIlsDQotneNA7JCmGfZdDrAv2u0NQFAtgn9e1xyfmR/rhc63fM+CHR3zaHu8+jySQae/SBuAObdAD3w153SB3+f0euHHI7YGSmLu9wlma5wosZtAzsF/D2gLInQEhY9A7IN0b1DdSQNfnBkevRwsFkFLSm569IWFsyC38r+32YcmQiEUFgyJPsPRhD+IeRGogTAG4TKYnhoOuPa4rvUMQ7Qm6l8WcBvY+b8A/4NovVAjuIc9IwO/ywzSQ9MHEoDcgBAty/7Bv0CelVfQHg/41lZUjIyMVg3rCVrh9g5X9wcGBysGg+NuSysHALpdYeIVA/pUMI54BYD2SZfOWzo2tG5saOzdu2axtadU+ubGpZXNHi9Z48baWlk0tmzsT4xPjO/vh1hmvCReLmMBQrCAoPXqeLSYXIxJZrLl3v7bfFxKcbpFt8LPcR7G0RHLIHEV8sf2GQO7aM+zxiEys0LrB1u9CGvh6xTYCZ3CBMSI7R0Q6eRA4j/D0sMcdRJx3w49zdokQ+vZ4JIkM8SwfQoPs7Q0FIRpm+rCj5i2oODBjFBJ51hWzzCLbtH2ugZCrFxnmCiBD5nNXaNuHZM7un1kF1qRXLqS3Swv4PW4vis65K9fgxSGZbYLX1dfnFTmBrByWVXmZQA9L38rd/SGjBryDXrEgKJF0I77hywOxJJX5KJG+ERTUUO+AN9Av9EBWzN2DSFTYj1D592ux5NU9tFCR9MfG3XOLE9Vrb8gTkGpQ99ye4SF9BcO63ZI40O8LDfRhD+3zekZi5eqc5Qs6RNKDCtA3V+Jm1wizZGF1B+diLBbm0q3efX6x0uRZBn3f64KgxxVcIwi2dzTiEChZVVNXqtUtX1VeVVNVFRe3vQ3IquXLa2pwrVtRp9WtrF1duzox/iN23cduRjGq1M2T+xCPqx79Jknc6sz/mGXhTJBCLBG3Bm8toJnD7qaFH3NrOqZV/9Bj/oyOU25QnlG+o5zEdXz+/AL8ha8NLnxtcOFrgwtfG1z42uDC1wYXvja48LXBha8NLnxtcOFrgwtfG1z42uDC1wYXvjb4f/hrg9nPD7z0UZ8sxGY+iT6WrT6JCS2gPXf2Ylk1AguoZnCt9BbGl9N7oH8LuIWfOiycm+GZub/ynVfi3OwlEppPE8NskKN98vOOhfMLZ9r10zckn/18clfOpz7f/HxP+T7Shz7Vpq5T16pN6kp1lepUL1Lb1NXzqc8733neT3TmsK3nrCeGaRMjthw08+fmsG36venlH7J4Hp6l0C8VO7Jk3vws7q/Nm7/SN3+1vI/LK/3/y1O0mH5K53l9mzqVr1AyY2SLTilfnrCkVzsnlbsnktOqnY0W5U5qR+MUVjbRFBonn3IbHUTjIG+LlC+vPiaAifikagvobyIN7RCaQmO4Mjl2ogn6mybSMoX4ayLJKZLvs5GqmhgwYbFWtzemK1cQUzzKENnJphxAvxi9G30++l6lD5VC2OmcSLZUH4K+BpA3KBkoQzalUcmkavTNSg7lSrJQJCmmJxQpKatujFeaFKskSVYSUY9silkxRapt2glF/NmwU7lhIm6RsO+GiCWj+hnlOsVE6aA6BKosW/IzSjxVoomVdE7EJVYfbkxQOrHMTrjFpoj/rH+fvDqVoQgEQV+LkkeZmLtcyacM9K3K4kiGbeqEcrsk+zshBfrWRcwrRDeRmFQ91RiniL8HCCu3wuO3Sm2HJ4pWVVNjkVJCVYr4EwlNOQjooPjP4soooFGEaRShGUVoRmHFKBkR+RsxcyNoKpUrya+M0GG0+wCrEJkRgQePSWBpSfUxJVuxwhOWE/AdAzZnIi5JWGaNpKZJMutEQlJ1wzNKgLagcRgfnMiyVvtOKGVyKcsmrLmCwR+JS4DrsmKxAGOmiMEzSp6yWHoiX3og3GjDmFGyYiPGf8BPCe/wl/mPRXzFT/rI/h/1/kW9/2Gsj07xUxPQ4pzk/yz60415/A0I28VfpfsAcX6CP4+jxsZ/zieFFfxn/Bg1oH8F4z70x9CvQH88UvA92ySfnEAH2++JJGaKxfLnI45KHbAV6kBWrg6kZlY3FvLn+LOUBxE/Rb8U/bN8ipagP4nein6KB+l76J/gtbQW/VG9/w5/WuQ0f4o/iTPTxiciScKEcMQkuiMRo+i+FaHYqL3S9jT/Fn+cckD6zUhRDrCPTBQttSWfgDzGH+TBSL4ttTGe38+62LsgGqNXRE+p/IFInRByOPK0ZjvGD/PDTmuds9BZ7nxIqSqsKq96SNEKtXKtTntIa7TwW8kA52HD8ptwxfnMkT1oTrTD/MaIWhduPIs1iXVxOoTrmIR6cPVLiHC1zM6+I6EGfh1tQeOQcQDtINohtKtIxfVKtM+ifQ7t8xITRAuhjaB8+MHhB4cfHH7J4QeHHxx+cPglh19qD6EJjh5w9ICjBxw9kqMHHD3g6AFHj+QQ9vaAo0dytIOjHRzt4GiXHO3gaAdHOzjaJUc7ONrB0S45nOBwgsMJDqfkcILDCQ4nOJySwwkOJzickqMKHFXgqAJHleSoAkcVOKrAUSU5qsBRBY4qyaGBQwOHBg5Ncmjg0MChgUOTHBo4NHBoksMCDgs4LOCwSA4LOCzgsIDDIjksMj4hNMFxGhynwXEaHKclx2lwnAbHaXCclhynwXEaHKf5yLhyqvEFsJwCyymwnJIsp8ByCiynwHJKspwCyymwnNKXHpTO4EibA2gH0Q6hCd4p8E6Bdwq8U5J3SqZXCE3whsERBkcYHGHJEQZHGBxhcIQlRxgcYXCEJccYOMbAMQaOMckxBo4xcIyBY0xyjMnEDaEJjr89Kf/m0PCrWJcZhys/xEplf5Delv0BekX2n6dx2X+OHpL9Z+lq2V9JdbIfoSLZQ57sg2Qzs4itLrkxEyVgC9ouNB/afWhH0E6imST0EtpraFFe61yiJpu2mO4zHTGdNBmOmE6beLJxi/E+4xHjSaPhiPG0kWuNuTxR1lGUFvqivB7E9fdoOERwbZBQA6+B3hrU2Vq8a3iNM+WM9vsy9lIZO1nGjpSxL5axxjh+MVNlpcOdPofhrMuZULTO9gpaXVHxOlSmW598O8sWKVppm2RPx7pSpwP922jjaA+hXY1Wh1aNVo5WiGaTuDLQdzmX6CKfRitGK0DThArKzMTdTWqK2XmMJ7KHJl5IpDihp7gEfCcixVXoJiPFW9A9FSnutTXGsSepWNwGsScQucfRH4nYXsf0N2PdNyK2E+geidhq0O2MFFeguzRS/KKtMZFtJ5sqWDv1vgPrFv22iO0SkG2N2ErROSLFRYK6DIoKMVvKuuh19IU619KYJnvEthbdkohttaA2U7EIPDNSuTTPgCZ6ZQIG/f4Y61KZc5HtjO1229tg/x0ci/T4mTaponupcJJd4oy3PV3+VRA32iKN8YIe58O43odF/4TtocIbbfdAFit80na3rcJ2a/mkGehbYPeNUkXEdrU2yR93ptkO2apswfLXbQHbJ2wu2zbbzkLgI7bLbE8LM6mbdfHHn7S1Q+BGrKIwYru4cFKa2Grbb3Paim2rtaeFf2lVTG5d+dPCA1Qd074M/i0rnBQ5vr1ukqU4y0zvmA6bLjWtN6012U1LTItN+aZ0c6rZYk4yJ5jjzWaz0ayauZnM6eLnHRzizyvTjeKv18moiqsqYQsXVx77S1POzJw+QeE0pY23daxnbeEpN7X1auH3OuyTLH7rjrDBvp6FU9uorXN9eJWjbdIU3Rauc7SFTe2Xdo0zdms3sGF+wySjzq5JFhWo63LFD1GNM7rultxjxFj2dbd0d5M1c1+DtSF1Xcrq1ubzXHr0q2PuZZ0P5ofvauvoCj+W3x2uFkA0v7stfJX4mapjPJkntjQf40mi6+46pvp5css2gVf9zd0ge12SIZuTQEbFogOZeT1pggz1ZL0gQ4xidEVgB12B6EAXn0hFkq4oPlHSqUzQjb+itTSPa5qkKSR6RdK8UkjzaJAx4G0eLyqSVHaNdQkq1mXXpGGlUpDNBpJymyTBk5tNCrIxqSxcOUdSqJPUzpLUSl0Km6OxxWjSS2Zo0ktA4/gfvjzrHWxieejA8+KXv3rsLR60nvBN+/qt4UO9mjZ+IKT/JFhRT6+7X/QuTzhk9zSHD9ibtfHlz59n+nkxvdzePE7Pt3R2jT/v9DRHljuXt9hdzd0TDfVdjQt03Tirq6v+PMLqhbAuoauh8TzTjWK6QehqFLoaha4GZ4PU1eIVed/eNW6m9eJ3QWQ/wRfFI4d7cgu612da/OtEQh9bW2A9kHtcJfYILXJ0hxPs68OJaGKqvLG8UUxhn4mpJPHzbvqU9cDagtzj7BF9ygJ0in09zbiWBFFbuHZrW7igY0eXSJWw03X+mAXES05bqcXbjH8YB2XDez4lBc77Cp7vFQqFAuIScuApuS1c1tEWXrkVlphMUNXT3A1cxQxOUSRuPC6uZTI6hUkHjGBBoU5ADiZ+I8AZj6cuEx8zjpm4eFQITuTkV/uewQl+EA3PcXwkUimfl/nIxJJC8fwSnKisjfV4PhV9JKegWvwUQR1YRV8Y650p5QAOFx4uP1w3VjhWPlZnFD+08BCQtofEURqpfEihoCMw4wiAwW6K/XQB9N0fycuXiscE4HB0OwLyN17ow6526L8jA6fPOjagSw1I8cGZgMTwAYoRxyYdoRmmkM4iJ0OSRSr8P1jbNhMKZW5kc3RyZWFtCmVuZG9iagoKNiAwIG9iagoxMDgyNQplbmRvYmoKCjcgMCBvYmoKPDwvVHlwZS9Gb250RGVzY3JpcHRvci9Gb250TmFtZS9CQUFBQUErQXJpYWwtQm9sZE1UCi9GbGFncyA0Ci9Gb250QkJveFstNjI3IC0zNzYgMjAwMCAxMDExXS9JdGFsaWNBbmdsZSAwCi9Bc2NlbnQgOTA1Ci9EZXNjZW50IDIxMQovQ2FwSGVpZ2h0IDEwMTAKL1N0ZW1WIDgwCi9Gb250RmlsZTIgNSAwIFI+PgplbmRvYmoKCjggMCBvYmoKPDwvTGVuZ3RoIDI3Mi9GaWx0ZXIvRmxhdGVEZWNvZGU+PgpzdHJlYW0KeJxdkc9uhCAQxu88BcftYQNadbuJMdm62cRD/6S2D6AwWpKKBPHg2xcG2yY9QH7DzDf5ZmB1c220cuzVzqIFRwelpYVlXq0A2sOoNElSKpVwe4S3mDpDmNe22+JgavQwlyVhbz63OLvRw0XOPdwR9mIlWKVHevioWx+3qzFfMIF2lJOqohIG3+epM8/dBAxVx0b6tHLb0Uv+Ct43AzTFOIlWxCxhMZ0A2+kRSMl5RcvbrSKg5b9cskv6QXx21pcmvpTzLKs8p8inPPA9cnENnMX3c+AcOeWBC+Qc+RT7FIEfohb5HBm1l8h14MfIOZrc3QS7YZ8/a6BitdavAJeOs4eplYbffzGzCSo83zuVhO0KZW5kc3RyZWFtCmVuZG9iagoKOSAwIG9iago8PC9UeXBlL0ZvbnQvU3VidHlwZS9UcnVlVHlwZS9CYXNlRm9udC9CQUFBQUErQXJpYWwtQm9sZE1UCi9GaXJzdENoYXIgMAovTGFzdENoYXIgMTEKL1dpZHRoc1s3NTAgNzIyIDYxMCA4ODkgNTU2IDI3NyA2NjYgNjEwIDMzMyAyNzcgMjc3IDU1NiBdCi9Gb250RGVzY3JpcHRvciA3IDAgUgovVG9Vbmljb2RlIDggMCBSCj4+CmVuZG9iagoKMTAgMCBvYmoKPDwKL0YxIDkgMCBSCj4+CmVuZG9iagoKMTEgMCBvYmoKPDwvRm9udCAxMCAwIFIKL1Byb2NTZXRbL1BERi9UZXh0XT4+CmVuZG9iagoKMSAwIG9iago8PC9UeXBlL1BhZ2UvUGFyZW50IDQgMCBSL1Jlc291cmNlcyAxMSAwIFIvTWVkaWFCb3hbMCAwIDU5NSA4NDJdL0dyb3VwPDwvUy9UcmFuc3BhcmVuY3kvQ1MvRGV2aWNlUkdCL0kgdHJ1ZT4+L0NvbnRlbnRzIDIgMCBSPj4KZW5kb2JqCgoxMiAwIG9iago8PC9Db3VudCAxL0ZpcnN0IDEzIDAgUi9MYXN0IDEzIDAgUgo+PgplbmRvYmoKCjEzIDAgb2JqCjw8L1RpdGxlPEZFRkYwMDQ0MDA3NTAwNkQwMDZEMDA3OTAwMjAwMDUwMDA0NDAwNDYwMDIwMDA2NjAwNjkwMDZDMDA2NT4KL0Rlc3RbMSAwIFIvWFlaIDU2LjcgNzczLjMgMF0vUGFyZW50IDEyIDAgUj4+CmVuZG9iagoKNCAwIG9iago8PC9UeXBlL1BhZ2VzCi9SZXNvdXJjZXMgMTEgMCBSCi9NZWRpYUJveFsgMCAwIDU5NSA4NDIgXQovS2lkc1sgMSAwIFIgXQovQ291bnQgMT4+CmVuZG9iagoKMTQgMCBvYmoKPDwvVHlwZS9DYXRhbG9nL1BhZ2VzIDQgMCBSCi9PdXRsaW5lcyAxMiAwIFIKPj4KZW5kb2JqCgoxNSAwIG9iago8PC9BdXRob3I8RkVGRjAwNDUwMDc2MDA2MTAwNkUwMDY3MDA2NTAwNkMwMDZGMDA3MzAwMjAwMDU2MDA2QzAwNjEwMDYzMDA2ODAwNkYwMDY3MDA2OTAwNjEwMDZFMDA2RTAwNjkwMDczPgovQ3JlYXRvcjxGRUZGMDA1NzAwNzIwMDY5MDA3NDAwNjUwMDcyPgovUHJvZHVjZXI8RkVGRjAwNEYwMDcwMDA2NTAwNkUwMDRGMDA2NjAwNjYwMDY5MDA2MzAwNjUwMDJFMDA2RjAwNzIwMDY3MDAyMDAwMzIwMDJFMDAzMT4KL0NyZWF0aW9uRGF0ZShEOjIwMDcwMjIzMTc1NjM3KzAyJzAwJyk+PgplbmRvYmoKCnhyZWYKMCAxNgowMDAwMDAwMDAwIDY1NTM1IGYgCjAwMDAwMTE5OTcgMDAwMDAgbiAKMDAwMDAwMDAxOSAwMDAwMCBuIAowMDAwMDAwMjI0IDAwMDAwIG4gCjAwMDAwMTIzMzAgMDAwMDAgbiAKMDAwMDAwMDI0NCAwMDAwMCBuIAowMDAwMDExMTU0IDAwMDAwIG4gCjAwMDAwMTExNzYgMDAwMDAgbiAKMDAwMDAxMTM2OCAwMDAwMCBuIAowMDAwMDExNzA5IDAwMDAwIG4gCjAwMDAwMTE5MTAgMDAwMDAgbiAKMDAwMDAxMTk0MyAwMDAwMCBuIAowMDAwMDEyMTQwIDAwMDAwIG4gCjAwMDAwMTIxOTYgMDAwMDAgbiAKMDAwMDAxMjQyOSAwMDAwMCBuIAowMDAwMDEyNDk0IDAwMDAwIG4gCnRyYWlsZXIKPDwvU2l6ZSAxNi9Sb290IDE0IDAgUgovSW5mbyAxNSAwIFIKL0lEIFsgPEY3RDc3QjNEMjJCOUY5MjgyOUQ0OUZGNUQ3OEI4RjI4Pgo8RjdENzdCM0QyMkI5RjkyODI5RDQ5RkY1RDc4QjhGMjg+IF0KPj4Kc3RhcnR4cmVmCjEyNzg3CiUlRU9GCg==`;

  getImagesAsBase64Fun() {
    // getImagesAsBase64({ TermConditionId: "a1seX000000Eu5ZQAS" })
    // .then((result) => {
    //   console.log("base 64 data", (result.filebase64));
    //   this.base64Pdf = result.filebase64;
    // })
    // .catch((e) => console.error("error in base64 class", e));
  }
}