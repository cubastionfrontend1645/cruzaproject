import { LightningElement } from 'lwc';

export default class Cruza_header extends LightningElement {

}