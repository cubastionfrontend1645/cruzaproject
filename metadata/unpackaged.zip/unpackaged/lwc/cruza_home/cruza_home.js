import { LightningElement } from 'lwc';

export default class Cruza_home extends LightningElement {}