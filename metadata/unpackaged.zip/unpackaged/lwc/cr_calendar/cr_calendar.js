import { LightningElement } from 'lwc';

export default class Cr_calendar extends LightningElement {}