import { LightningElement } from 'lwc';

export default class Cruza_footer extends LightningElement { }